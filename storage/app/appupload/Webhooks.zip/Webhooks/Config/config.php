<?php

return [
    'name' => 'Webhooks',
    'webhook_by_admin'=>env('WEBHOOK_BY_ADMIN',''),
    'webhook_by_vendor'=>env('WEBHOOK_BY_VENDOR','')
];
